from flask import Flask, send_from_directory

app = Flask(__name__)

STATIC_FOLDER = "static"
DATA_FOLDER = "data"

@app.route('/')
def index():
    return send_from_directory(STATIC_FOLDER, "index.html")

@app.route('/data/<filename>')
def serve_data(filename):
    return send_from_directory(DATA_FOLDER, filename)

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=1121)