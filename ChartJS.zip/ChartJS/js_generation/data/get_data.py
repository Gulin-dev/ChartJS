import requests
import pandas as pd
from datetime import datetime, timedelta
from xml.etree import ElementTree as ET
import json


def fetch_currency_data(start_date, end_date):
    start_date_str = start_date.strftime("%d/%m/%Y")
    end_date_str = end_date.strftime("%d/%m/%Y")

    url = f"http://www.cbr.ru/scripts/XML_dynamic.asp"
    params = {
        "date_req1": start_date_str,
        "date_req2": end_date_str,
        "VAL_NM_RQ": "R01235"
    }

    response = requests.get(url, params=params)
    if response.status_code == 200:
        return response.text
    else:
        print(f"Ошибка при загрузке данных: {response.status_code}")
        return None


def parse_xml_data(xml_data):
    root = ET.fromstring(xml_data)
    data = []
    for record in root.findall("Record"):
        date = record.attrib["Date"]
        value = record.find("Value").text.replace(",", ".")
        data.append({"Date": date, "Rate": float(value)})
    return data


def save_to_json(data, filename="currency_data.json"):
    data.sort(key=lambda x: datetime.strptime(x["Date"], "%d.%m.%Y"))

    with open(filename, "w", encoding="utf-8") as file:
        json.dump(data, file, ensure_ascii=False, indent=4)
    print(f"Данные успешно сохранены в файл {filename}")


def load_from_json(filename="currency_data.json"):
    try:
        with open(filename, "r", encoding="utf-8") as file:
            data = json.load(file)
        return pd.DataFrame(data)
    except FileNotFoundError:
        return pd.DataFrame()


def main():
    existing_data = load_from_json()

    end_date = datetime.now()
    start_date = end_date - timedelta(days=7200)

    all_data = []

    while len(all_data) < 10:
        xml_data = fetch_currency_data(start_date, end_date)
        if xml_data is None:
            print("Не удалось получить новые данные.")
            return

        new_data = parse_xml_data(xml_data)

        all_data.extend(new_data)

        all_data = list({item["Date"]: item for item in all_data}.values())

        if len(all_data) < 10:
            print(f"Получено только {len(all_data)} дней данных. Расширяем диапазон дат...")
            start_date -= timedelta(days=10)

    new_df = pd.DataFrame(all_data)

    if not existing_data.empty:
        combined_df = pd.concat([existing_data, new_df]).drop_duplicates()
    else:
        combined_df = new_df

    save_to_json(combined_df.to_dict(orient="records"))

    dates = pd.to_datetime(combined_df["Date"], format="%d.%m.%Y")
    missing_dates = pd.date_range(start=dates.min(), end=dates.max()).difference(dates)
    if not missing_dates.empty:
        print(f"Внимание: Пропущены следующие даты: {missing_dates.strftime('%d.%m.%Y').tolist()}")


if __name__ == "__main__":
    main()