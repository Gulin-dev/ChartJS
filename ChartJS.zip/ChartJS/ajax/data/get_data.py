import requests
import json
from datetime import datetime, timedelta
from xml.etree import ElementTree as ET

DATA_FILE = "../static/data.json"

def fetch_currency_data(start_date, end_date):
    url = "http://www.cbr.ru/scripts/XML_dynamic.asp"
    params = {
        "date_req1": start_date.strftime("%d/%m/%Y"),
        "date_req2": end_date.strftime("%d/%m/%Y"),
        "VAL_NM_RQ": "R01235"
    }
    response = requests.get(url, params=params)
    return response.text if response.status_code == 200 else None

def parse_xml(xml_data):
    root = ET.fromstring(xml_data)
    data = []
    for record in root.findall("Record"):
        date = record.attrib["Date"]
        rate = float(record.find("Value").text.replace(",", "."))
        data.append({"Date": date, "Rate": rate})
    return data

def save_data(data):
    data.sort(key=lambda x: datetime.strptime(x["Date"], "%d.%m.%Y"))
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data[-10:], f, ensure_ascii=False, indent=4)

def update_data():
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            existing = json.load(f)
    except FileNotFoundError:
        existing = []

    end_date = datetime.now()
    start_date = end_date - timedelta(days=30)

    xml_data = fetch_currency_data(start_date, end_date)
    if not xml_data:
        print("Ошибка загрузки данных")
        return

    new_data = parse_xml(xml_data)
    combined = {item["Date"]: item for item in existing + new_data}.values()
    save_data(list(combined))

if __name__ == "__main__":
    update_data()