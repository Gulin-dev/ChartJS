from flask import Flask, render_template, jsonify
import os
import json

app = Flask(__name__, static_folder="static", template_folder="static")

DATA_FILE = os.path.join("static", "data.json")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/currency")
def currency():
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return jsonify(sorted(data, key=lambda x: x["Date"]))
    except:
        return jsonify([])

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=1121)