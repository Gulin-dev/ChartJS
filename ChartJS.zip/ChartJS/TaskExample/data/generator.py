# Генератор данных с определенной периодичностью

import pymysql
from pymysql.cursors import DictCursor
import time
import random


# Соединяемся с базой данных
dbh = pymysql.connect(
    host='db-learning.ithub.ru',
    user='teacher',
    password='a-007-007-007',
    db='teacher',
    charset='utf8mb4',
    cursorclass=DictCursor,
    autocommit=True
)

while True:
    d = random.uniform(0, 20)
    #print(d)

    try:
        with dbh.cursor() as cur:
            sql = "INSERT INTO vd_data_3p2 (d) VALUES('"+str(d)+"')"
            print(sql)
            cur.execute(sql)
    except:
        print("Что-то пошло не так")

    time.sleep(1)