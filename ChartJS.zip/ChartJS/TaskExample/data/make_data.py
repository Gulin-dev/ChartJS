import pymysql
from pymysql.cursors import DictCursor


# Соединяемся с базой данных
dbh = pymysql.connect(
        host='db-learning.ithub.ru',
        user='teacher',
        password='a-007-007-007',
        db='ithub',
        charset='utf8mb4',
        cursorclass=DictCursor
    )

try:
    with dbh.cursor() as cur:
        cur.execute('SELECT * FROM vd_population ORDER BY population DESC')
        rows = cur.fetchall()

        vd_labels = []
        vd_data2019 = []
        vd_data2020 = []
        for row in rows:
            vd_labels.append(row['country'])
            vd_data2020.append(row['population'])
            vd_data2019.append(row['population2019'])
        
        # Создаём статический файл с данными
        o = 'labels = ['
        c = 0
        for l in vd_labels:
            if c > 0:
                o += ','
            o += '"' + l + '"'
            c += 1
        o += ']\n\n'
        
        o += "population = {\n  '2019': ["
        
        c = 0
        for l in vd_data2019:
            if c > 0:
                o += ','
            o += str(l)
            c += 1
        o += '],\n'
        
        o += "  '2020': ["
        
        c = 0
        for l in vd_data2020:
            if c > 0:
                o += ','
            o += str(l)
            c += 1
        o += ']\n'
        
        o += '}\n'
        
        print(o)
        
        fh = open('../static/data.js', 'w')
        fh.write(o)
        fh.close()

except Exception as er:
    print("Что-то пошло не так", er)

