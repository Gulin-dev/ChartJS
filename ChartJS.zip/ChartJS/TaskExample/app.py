from flask import Flask, Response, request
import json
import random
import time

# Создаем свой веб-сервер
app = Flask(__name__)

@app.route('/', methods=['GET'])
def index():
    fh = open('static/charts-js.html', 'r')
    cnt = fh.read()
    fh.close()
    
    return cnt 
    

app.run(debug=True, host='db-learning.ithub.ru', port=1199)
