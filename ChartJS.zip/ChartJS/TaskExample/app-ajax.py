from flask import Flask, Response, request, jsonify
import json
import random
import time
import pymysql
from pymysql.cursors import DictCursor

# Создаем свой веб-сервер
app = Flask(__name__)

# Соединяемся с базой данных
dbh = pymysql.connect(
        host='185.12.94.106',
        user='teacher',
        password='a-007-007-007',
        db='teacher',
        charset='utf8mb4',
        cursorclass=DictCursor,
        autocommit=True
    )

@app.route('/', methods=['GET'])
def index():
    fh = open('static/charts-ajax.html', 'r')
    cnt = fh.read()
    fh.close()
    
    return cnt 

@app.route('/get_data', methods=['POST'])
def get_data():
    d = []

    d_dt = []
    d_data = []
    try:
        with dbh.cursor() as cur:
            cur.execute('SELECT * FROM vd_data_3p2 ORDER BY dt DESC LIMIT 20')
            rows = cur.fetchall()

            for row in rows:
                d_dt.append(row['dt'])
                d_data.append(row['d'])

            d = [ d_dt, d_data ]
    except:
        d = { 'error': 'Ошибка чтения' }


    return jsonify(d)  

app.run(debug=True, host='0.0.0.0', port=1199)
