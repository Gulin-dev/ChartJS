var popBarId = $("#bar");

popBar = new Chart(popBarId, {
    type: 'bar',
    data: {
        labels: labels,
		datasets: [
            {
                label: 'Популяция 2019 г',
                data: population['2019'],
				backgroundColor: 'rgba(255, 99, 132, 0.2)',
                borderWidth: 1,
                borderColor: 'rgba(255, 99, 132, 1)' 
			},
			{
                label: 'Популяция 2020 г',
                data: population['2020'],
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderWidth: 1,
                borderColor: 'rgba(54, 162, 235, 1)'
            }
		]
	},
	options: {
		plugins: {
            legend: {
                display: true,
                position: "bottom",
				labels: {
					boxWidth: 30,
					color: "black",
					font: {
						size: 20,
						/*
						weight: "bold",
						style: "italic"
						*/
					}
				}
            }
        }
	}
});

